# Exodus
A Minecraft Exploit Fixer that modifies packets to prevent chunkbans, kicks and more.

# Requirements
- ProtocolLib

exodusfixer
by lome4
